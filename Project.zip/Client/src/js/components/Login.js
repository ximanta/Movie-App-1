var React = require('react');
var Login = React.createClass({
  getInitialState:function(){
    return {
      username:"",
      password:""
    };
  },
  UserChangeHandler:function(evt){
    this.setState({username:evt.target.value});
  },
  PassChangehandler:function(evt){
    this.setState({password:evt.target.value});
  },
  ClickHandler:function(){
    $.ajax({
      url:"http://localhost:8080/login",
      type:"POST",
      datatype:"JSON",
      data:this.state,
      success:function(data){
        alert(data);
      }.bind(this),
      error:function(err){
        console.log(err);
      }.bind(this)
    });
  },
render:function(){
  return (
    <div>
    <p>Username:</p><input type="text" onChange={this.UserChangeHandler} ></input>
    <p>Password:</p><input type="password" onChange={this.PassChangehandler} ></input>
    <p><input type="button" onClick={this.ClickHandler} value="Login"></input></p>
    </div>
  )
}
});
module.exports= Login;
