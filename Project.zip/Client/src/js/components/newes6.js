var React = require('react');
var New = React.createClass({
  render
});
module.exports = New;
