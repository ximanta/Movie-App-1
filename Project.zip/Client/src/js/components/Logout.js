var React = require('react');
var Logout = React.createClass({
  render:function(){
    $.ajax({
      url:"http://localhost:8080/logout",
      type:"JSON",
      success:function(data){
        console.log(data);
      },
      error:function(err){
        console.log(err);
      }
    });
    return(
      <div>
      <h3>User Logged Out</h3>
      </div>
    )
  }
});
module.exports = Logout;
